
<!DOCTYPE html>
<html lang="fr">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>67 Messaging - Login</title>
    <link rel="stylesheet" href="CSS/styles.css">
</head>

<body>
    <div class="centre_ecran" name="box_formulaire">
        <form method="POST" action="modele/createSession.php">
            <div name="login">
                <h5>Login</h5>
                <input type="text" name="login" required>
            </div>
            <div name="password">
                <h5>Password</h5>
                <input type="password" name="password" required><br>
            </div>

            <input type="submit" value="Valider" id="ValidationConnexion">
        </form>
    </div>
</body>

</html>